﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2NLP
{
    class Taglist
    {
        public string word { get; set; }
        public string tag { get; set; }
    }
}
