﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;

namespace Question2NLP
{
    class Program
    {
        static string text;
        static List<Taglist> list;

        private static void Main(string[] args) 
        {
            CalculateMLT();

            Console.WriteLine("WELCOME TO THE POS TAGGER PROGRAM:");
            Console.WriteLine("------------------------------------");
            Console.WriteLine(" ");
            Console.WriteLine("Select 1 - Implement Most Likely Tag");
            Console.WriteLine("Select 2 - Create New Annotated File");
            Console.WriteLine("Select 3 - Implement the Confusion Matrix");
            string input = Console.ReadLine();

            if (input == "1")
            {
                CalculateMLT();
            }else if(input == "2")
            {
                
                var filePath = string.Empty;

                Console.Write("Please enter the file path: ");
                filePath = Console.ReadLine();
                Console.WriteLine(filePath);
                Console.ReadLine();

                WriteNewFile(@filePath);
            }
        }

        public static void CalculateMLT()
        {
            Hashtable hashTable = new Hashtable();
            Hashtable tt = new Hashtable();
            Hashtable tt2 = new Hashtable();

            list = new List<Taglist>();
            List<Tags> tgs = new List<Tags>();
            List<Tags> tgsDist = new List<Tags>();

            text = File.ReadAllText(@"..\..\pos_tagged.txt");

            
            string[] wordstags = text.Split(' ');
            foreach (var wordtag in wordstags)
            {
                string[] words = wordtag.Split('/');
                Taglist tags = new Taglist();
                Tags tfs = new Tags();

                tags.word = words[0];
                tags.tag = words[1];
                tfs.tag = words[1];

                if (hashTable.ContainsKey(words[0]))
                {

                }
                else
                {
                    hashTable.Add(words[0], words[1]);
                }

                list.Add(tags);
                tgs.Add(tfs);
                
            }
            
            int count = 0;
            foreach (var g in hashTable.Keys)
            {


                foreach (var h in list)
                {
                    if (h.word == g.ToString())
                    {
                        count += 1;
                    }
                    else
                    {

                    }
                    
                }
                tt.Add(g, count);
                count = 0;
            }

            ICollection keys = tt.Keys;


            double count2 = 0;
            double count3 = 0;

            foreach (var y in keys)
            {
                foreach(var u in list)
                {
                    if (u.word == y.ToString())
                    {
                        Console.WriteLine(u.word);
                        foreach(var z in list)
                        {
                            
                            if (z.tag == u.tag & z.word == u.word)
                            {
                                count2 += 1;
                                
                            }
                            else
                            {

                            }
                            
                            if (z.word == u.word)
                            {
                                count3 += 1;
                            }
                        }
                        if (tt2.ContainsKey(u.word + " " + u.tag))
                        {

                        }
                        else
                        {
                            tt2.Add(u.word + " " + u.tag, count2 + "/" + count3 + " = " + count2 / count3 + "");
                            using (System.IO.StreamWriter file =
                                new System.IO.StreamWriter(@"..\..\outputFile.txt", true))
                            {
                                file.WriteLine(u.word + " : " + u.tag);

                                file.WriteLine(count2 + "/" + count3 + " = " + Double.Parse(count2 / count3 + ""));
                                file.WriteLine(" ");
                            }

                            count2 = 0;
                            count3 = 0;
                            
                        }
                    }
                    else
                    {

                    }
                    
                }
            }

            ICollection keys1 = tt2.Keys;

            foreach (var t in keys1)
            {
                Console.WriteLine(t + "\n " + " : " + tt2[t]);
            }
            Console.ReadLine();
        }

        public static void WriteNewFile(string fileName)
        {
            List<Tags> tgs = new List<Tags>();
            List<Tags> tgsDist = new List<Tags>();

            string text1 = File.ReadAllText(@"..\..\pos_test.txt");


            string[] wordstags = text1.Split(' ');
            foreach (var wordtag in wordstags)
            {
                string lack = null;
                var item = list.Find(x => x.word == wordtag);

                if (item != null)
                {
                    lack = wordtag + "/"+item.tag;
                }
                else
                {
                    lack = wordtag + "/NN";
                }

                using (System.IO.StreamWriter file =
                                new System.IO.StreamWriter(@fileName, true))
                {
                    file.Write(lack + " ");
                }
            }
        }
    }
}
